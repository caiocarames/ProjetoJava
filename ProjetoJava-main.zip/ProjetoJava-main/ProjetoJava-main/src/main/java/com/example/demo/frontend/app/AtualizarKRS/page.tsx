import AtualizarKRS from "./PaginaAtualizarKRS";

export default function Main(){
    return <AtualizarKRS></AtualizarKRS>
}