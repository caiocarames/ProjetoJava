(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_objetivos_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_objetivos_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_objetivos_PaginaObjetivos_module_5779519f.css",
    "static/chunks/app_objetivos_386ec6ec._.js"
  ],
  "source": "dynamic"
});
