import React from "react";

export default function HomePage() {
  return (
    <div className="fundo">
      <h2 className="tit_home">Bem-vindo à Home!</h2>
    </div>
  );
}