(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_AtualizarKRS_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_AtualizarKRS_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_AtualizarKRS_PaginaAtualizarKRS_module_cf577afd.css",
    "static/chunks/app_AtualizarKRS_686858cb._.js"
  ],
  "source": "dynamic"
});
