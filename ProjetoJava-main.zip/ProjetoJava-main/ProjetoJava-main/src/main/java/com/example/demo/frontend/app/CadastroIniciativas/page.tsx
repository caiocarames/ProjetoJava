import CadastroIniciativas from "./PaginaCadastroIniciativas";

export default function Main() {
  return <CadastroIniciativas></CadastroIniciativas>;
}
