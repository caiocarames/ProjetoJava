import CadastroKRS from "./PaginaCadastroKRS";

export default function Main() {
  return <CadastroKRS></CadastroKRS>;
}
