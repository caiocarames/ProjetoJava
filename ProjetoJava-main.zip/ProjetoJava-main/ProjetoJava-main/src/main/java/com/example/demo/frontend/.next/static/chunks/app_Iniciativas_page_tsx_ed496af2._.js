(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Iniciativas_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Iniciativas_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_Iniciativas_PaginaIniciativas_module_58075fa5.css",
    "static/chunks/app_Iniciativas_16b2a819._.js"
  ],
  "source": "dynamic"
});
