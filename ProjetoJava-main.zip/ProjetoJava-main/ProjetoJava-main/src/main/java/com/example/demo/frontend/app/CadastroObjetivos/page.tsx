import CadastroObjetivos from "./PaginaCadastroObjetivos";
export default function Main() {
  return <CadastroObjetivos></CadastroObjetivos>;
}
