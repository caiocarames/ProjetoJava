(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_resultadosChave_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_resultadosChave_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_resultadosChave_PaginaKRS_module_71d7d681.css",
    "static/chunks/app_resultadosChave_f6b75725._.js"
  ],
  "source": "dynamic"
});
