import PaginaIniciativas from "./PaginaIniciativas";

export default function Main() {
  return <PaginaIniciativas></PaginaIniciativas>;
}
