(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_CadastroObjetivos_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_CadastroObjetivos_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_CadastroObjetivos_PaginaCadastroObjetivos_module_b4fff633.css",
    "static/chunks/app_CadastroObjetivos_cb2bc016._.js"
  ],
  "source": "dynamic"
});
