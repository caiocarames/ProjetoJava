import AtualizarObjetivos from "./PaginaAtualizarObjetivos";

export default function Main(){
    return <AtualizarObjetivos></AtualizarObjetivos>
}