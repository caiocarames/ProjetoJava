import SobreSite from "./PaginaSobreSite";

export default function Main() {
  return <SobreSite></SobreSite>;
}
