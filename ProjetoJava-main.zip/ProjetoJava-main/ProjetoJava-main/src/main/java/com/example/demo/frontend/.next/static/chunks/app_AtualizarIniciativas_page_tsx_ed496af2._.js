(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_AtualizarIniciativas_page_tsx_ed496af2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_AtualizarIniciativas_page_tsx_ed496af2._.js",
  "chunks": [
    "static/chunks/app_AtualizarIniciativas_PaginaAtualizarIniciativas_module_6d1c0faf.css",
    "static/chunks/app_AtualizarIniciativas_0bff5b39._.js"
  ],
  "source": "dynamic"
});
