import PaginaKRS from "./PaginaKRS";

export default function Main() {
    return <PaginaKRS></PaginaKRS>;
  }
