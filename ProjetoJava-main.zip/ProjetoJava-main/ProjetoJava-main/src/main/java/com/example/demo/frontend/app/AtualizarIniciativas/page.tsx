import AtualizarIniciativas from "./PaginaAtualizarIniciativas";

export default function Main(){
    return <AtualizarIniciativas></AtualizarIniciativas>
}