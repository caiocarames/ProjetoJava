import PaginaObjetivos from "./PaginaObjetivos";

export default function Main() {
  return <PaginaObjetivos></PaginaObjetivos>;
}
